# Fekra Team Backend
FastAPI app goes here.